CREATE DATABASE Quackstagram;

use Quackstagram;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password TEXT NOT NULL,
    bio TEXT NULL,
    profilePic TEXT NULL,
    join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    postCount INT DEFAULT 0 NULL,
    followersCount INT DEFAULT 0 NULL,
    followingCount INT DEFAULT 0 NULL,
    CONSTRAINT username UNIQUE (username),
    CONSTRAINT email UNIQUE (email)
);

-- Posts table
CREATE TABLE IF NOT EXISTS posts (
    post_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    caption VARCHAR(255) NULL,
    image TEXT NOT NULL,
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    likes_count INT DEFAULT 0,
    comments_count INT DEFAULT 0,
    CONSTRAINT posts_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
);

-- Create index on user_id in posts table
CREATE INDEX idx_posts_user_id ON posts (user_id);

-- Comments table
CREATE TABLE IF NOT EXISTS comments (
    comment_id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    user_id INT NOT NULL,
    content TEXT NOT NULL,
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT comments_ibfk_1 FOREIGN KEY (post_id) REFERENCES posts (post_id) ON DELETE CASCADE,
    CONSTRAINT comments_ibfk_2 FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
);

-- Create indices for comments table
CREATE INDEX idx_comments_post_id ON comments (post_id);
CREATE INDEX idx_comments_user_id ON comments (user_id);

-- Likes table
CREATE TABLE IF NOT EXISTS likes (
    user_id INT NOT NULL,
    post_id INT NOT NULL,
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, post_id),
    CONSTRAINT likes_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE,
    CONSTRAINT likes_ibfk_2 FOREIGN KEY (post_id) REFERENCES posts (post_id) ON DELETE CASCADE
);

-- Create index on post_id in likes table
CREATE INDEX idx_likes_post_id ON likes (post_id);

-- Follows table
CREATE TABLE IF NOT EXISTS follows (
    follower_id INT NOT NULL,
    following_id INT NOT NULL,
    follow_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (follower_id, following_id),
    CONSTRAINT follows_ibfk_1 FOREIGN KEY (follower_id) REFERENCES users (user_id) ON DELETE CASCADE,
    CONSTRAINT follows_ibfk_2 FOREIGN KEY (following_id) REFERENCES users (user_id) ON DELETE CASCADE
);

-- Create index on following_id in follows table
CREATE INDEX idx_follows_following_id ON follows (following_id);


-- Update the counters in users table to match the inserted data
UPDATE users u
SET postCount = (SELECT COUNT(*) FROM posts p WHERE p.user_id = u.user_id),
    followersCount = (SELECT COUNT(*) FROM follows f WHERE f.following_id = u.user_id),
    followingCount = (SELECT COUNT(*) FROM follows f WHERE f.follower_id = u.user_id);

-- Update the counters in posts table to match the inserted data
UPDATE posts p
SET likes_count = (SELECT COUNT(*) FROM likes l WHERE l.post_id = p.post_id),
    comments_count = (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.post_id);











-- Quackstagram Views

-- 1. User Behavior View: Shows user activity levels based on posts, comments, and likes
-- This view provides insights into user behavior by measuring engagement levels
CREATE VIEW user_activity_insights AS
SELECT 
    u.user_id,
    u.username,
    COUNT(DISTINCT p.post_id) AS posts_created,
    COUNT(DISTINCT c.comment_id) AS comments_made,
    COUNT(DISTINCT l.post_id) AS posts_liked,
    (COUNT(DISTINCT p.post_id) + COUNT(DISTINCT c.comment_id) + COUNT(DISTINCT l.post_id)) AS total_activity,
    DATEDIFF(CURRENT_TIMESTAMP, u.join_date) AS days_since_joined,
    ROUND((COUNT(DISTINCT p.post_id) + COUNT(DISTINCT c.comment_id) + COUNT(DISTINCT l.post_id)) / 
          GREATEST(DATEDIFF(CURRENT_TIMESTAMP, u.join_date), 1), 2) AS activity_per_day
FROM 
    users u
LEFT JOIN 
    posts p ON u.user_id = p.user_id
LEFT JOIN 
    comments c ON u.user_id = c.user_id
LEFT JOIN 
    likes l ON u.user_id = l.user_id
GROUP BY 
    u.user_id, u.username, u.join_date
HAVING 
    total_activity > 5
ORDER BY 
    total_activity DESC;

-- Performance check before index:
-- EXPLAIN SELECT * FROM user_activity_insights;

-- Add index to improve performance of the user_activity_insights view
CREATE INDEX idx_users_join_date ON users(join_date);
CREATE INDEX idx_comments_user_id_post_id ON comments(user_id, post_id);

-- Performance check after index:
-- EXPLAIN SELECT * FROM user_activity_insights;

-- 2. Content Popularity View: Shows the most popular content on the platform
-- This view helps understand what content is performing well
CREATE VIEW content_popularity_insights AS
SELECT 
    p.post_id,
    p.caption,
    u.username AS creator,
    p.create_time,
    p.likes_count,
    p.comments_count,
    (p.likes_count + p.comments_count) AS engagement_score,
    (SELECT COUNT(*) FROM follows f WHERE f.following_id = p.user_id) AS creator_followers,
    ROUND((p.likes_count + p.comments_count) / 
          GREATEST((SELECT COUNT(*) FROM follows f WHERE f.following_id = p.user_id), 1), 2) AS engagement_ratio
FROM 
    posts p
JOIN 
    users u ON p.user_id = u.user_id
WHERE 
    p.create_time >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 30 DAY)
GROUP BY 
    p.post_id, p.caption, u.username, p.create_time, p.likes_count, p.comments_count, creator_followers
HAVING 
    engagement_score > 5
ORDER BY 
    engagement_score DESC;

-- Performance check before index:
-- EXPLAIN SELECT * FROM content_popularity_insights;

-- Add index to improve performance of the content_popularity_insights view
CREATE INDEX idx_posts_create_time_likes_comments ON posts(create_time, likes_count, comments_count);

-- Performance check after index:
-- EXPLAIN SELECT * FROM content_popularity_insights;

-- 3. System Analytics View: Provides system-level insights for platform management
-- This view helps platform administrators monitor system health and growth
CREATE VIEW system_analytics_insights AS
SELECT 
    DATE(u.join_date) AS date,
    COUNT(DISTINCT CASE WHEN u.join_date >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 30 DAY) THEN u.user_id END) AS new_users_last_30days,
    COUNT(DISTINCT CASE WHEN p.create_time >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 30 DAY) THEN p.post_id END) AS new_posts_last_30days,
    COUNT(DISTINCT CASE WHEN c.create_time >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 30 DAY) THEN c.comment_id END) AS new_comments_last_30days,
    COUNT(DISTINCT CASE WHEN l.create_time >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 30 DAY) THEN CONCAT(l.user_id, '_', l.post_id) END) AS new_likes_last_30days,
    COUNT(DISTINCT CASE WHEN f.follow_date >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 30 DAY) THEN CONCAT(f.follower_id, '_', f.following_id) END) AS new_follows_last_30days,
    (SELECT AVG(subq.post_count) 
     FROM (SELECT COUNT(*) AS post_count FROM posts WHERE create_time >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 30 DAY) GROUP BY user_id) AS subq) AS avg_posts_per_active_user
FROM 
    users u
LEFT JOIN 
    posts p ON 1=1
LEFT JOIN 
    comments c ON 1=1
LEFT JOIN 
    likes l ON 1=1
LEFT JOIN 
    follows f ON 1=1
GROUP BY 
    DATE(u.join_date)
HAVING 
    (new_users_last_30days + new_posts_last_30days + new_comments_last_30days + new_likes_last_30days + new_follows_last_30days) > 0
ORDER BY 
    date DESC;

-- Performance check before index:
-- EXPLAIN SELECT * FROM system_analytics_insights;

-- Add index to improve performance of the system_analytics_insights view
CREATE INDEX idx_likes_create_time ON likes(create_time);
CREATE INDEX idx_comments_create_time ON comments(create_time);
CREATE INDEX idx_follows_follow_date ON follows(follow_date);










-- Quackstagram Triggers, Procedures, and Functions

DELIMITER //

-- Function to calculate engagement score for a post
CREATE FUNCTION calculate_engagement_score(post_likes INT, post_comments INT, creator_followers INT) 
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE engagement_score DECIMAL(10,2);
    
    -- Calculate engagement score (likes + comments) / followers
    -- If no followers, use 1 to avoid division by zero
    SET engagement_score = (post_likes + post_comments) / GREATEST(creator_followers, 1);
    
    RETURN engagement_score;
END //

-- Procedure to update user statistics
CREATE PROCEDURE update_user_stats(IN user_id_param INT)
BEGIN
    -- Update post count
    UPDATE users
    SET postCount = (SELECT COUNT(*) FROM posts WHERE user_id = user_id_param)
    WHERE user_id = user_id_param;
    
    -- Update followers count
    UPDATE users
    SET followersCount = (SELECT COUNT(*) FROM follows WHERE following_id = user_id_param)
    WHERE user_id = user_id_param;
    
    -- Update following count
    UPDATE users
    SET followingCount = (SELECT COUNT(*) FROM follows WHERE follower_id = user_id_param)
    WHERE user_id = user_id_param;
END //

-- Trigger to update post counters when a like is added or removed
CREATE TRIGGER after_like_insert
AFTER INSERT ON likes
FOR EACH ROW
BEGIN
    DECLARE creator_id INT;
    DECLARE creator_followers INT;
    DECLARE post_comments INT;
    DECLARE post_likes INT;
    
    -- Get post creator id
    SELECT user_id INTO creator_id
    FROM posts
    WHERE post_id = NEW.post_id;
    
    -- Update like count for the post
    UPDATE posts
    SET likes_count = likes_count + 1
    WHERE post_id = NEW.post_id;
    
    -- Get updated values for engagement score calculation
    SELECT likes_count, comments_count INTO post_likes, post_comments
    FROM posts
    WHERE post_id = NEW.post_id;
    
    -- Get creator's followers count
    SELECT followersCount INTO creator_followers
    FROM users
    WHERE user_id = creator_id;
    
    -- Log engagement score using our function
    INSERT INTO engagement_logs (post_id, user_id, engagement_score, action_type)
    VALUES (
        NEW.post_id,
        creator_id,
        calculate_engagement_score(post_likes, post_comments, creator_followers),
        'like_added'
    );
END //

-- Trigger to update counters when a follow relationship is created or removed
CREATE TRIGGER after_follow_insert
AFTER INSERT ON follows
FOR EACH ROW
BEGIN
    -- Update follower and following counts using our procedure
    CALL update_user_stats(NEW.follower_id);
    CALL update_user_stats(NEW.following_id);
END //

-- Create a table to log engagement scores (used by our trigger)
CREATE TABLE IF NOT EXISTS engagement_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    user_id INT NOT NULL,
    engagement_score DECIMAL(10,2) NOT NULL,
    action_type VARCHAR(50) NOT NULL,
    log_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_engagement_logs_post FOREIGN KEY (post_id) REFERENCES posts (post_id) ON DELETE CASCADE,
    CONSTRAINT fk_engagement_logs_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
) //

DELIMITER ;








-- Quackstagram Profit Maximization SQL Queries

-- 1. List all users who have more than X followers
SELECT u.user_id, u.username, COUNT(f.follower_id) AS follower_count
FROM users u
JOIN follows f ON u.user_id = f.following_id
GROUP BY u.user_id, u.username
HAVING follower_count > ? -- Replace ? with the desired X value
ORDER BY follower_count DESC;

-- 2. Show the total number of posts made by each user
SELECT u.user_id, u.username, COUNT(p.post_id) AS post_count
FROM users u
LEFT JOIN posts p ON u.user_id = p.user_id
GROUP BY u.user_id, u.username
ORDER BY post_count DESC;

-- 3. Find all comments made on a particular user's post
SELECT c.comment_id, c.content, u.username AS commenter, p.caption AS post_caption, 
       p.post_id, c.create_time
FROM comments c
JOIN posts p ON c.post_id = p.post_id
JOIN users u ON c.user_id = u.user_id
JOIN users post_owner ON p.user_id = post_owner.user_id
WHERE post_owner.user_id = ? -- Replace ? with the user ID
   OR post_owner.username = ? -- Replace ? with the username
ORDER BY p.post_id, c.create_time;

-- 4. Display the top X most liked posts
SELECT p.post_id, p.caption, u.username AS creator, p.image, p.likes_count
FROM posts p
JOIN users u ON p.user_id = u.user_id
ORDER BY p.likes_count DESC
LIMIT ?; -- Replace ? with the desired X value

-- 5. Count the number of posts each user has liked
SELECT u.user_id, u.username, COUNT(l.post_id) AS likes_given
FROM users u
LEFT JOIN likes l ON u.user_id = l.user_id
GROUP BY u.user_id, u.username
ORDER BY likes_given DESC;

-- 6. List all users who haven't made a post yet
SELECT u.user_id, u.username, u.email, u.join_date
FROM users u
LEFT JOIN posts p ON u.user_id = p.user_id
WHERE p.post_id IS NULL
ORDER BY u.join_date;

-- 7. List users who follow each other (mutual follows)
SELECT u1.user_id AS user1_id, u1.username AS user1_name, 
       u2.user_id AS user2_id, u2.username AS user2_name
FROM follows f1
JOIN follows f2 ON f1.follower_id = f2.following_id AND f1.following_id = f2.follower_id
JOIN users u1 ON f1.follower_id = u1.user_id
JOIN users u2 ON f1.following_id = u2.user_id
WHERE u1.user_id < u2.user_id -- To avoid duplicates (A follows B and B follows A)
ORDER BY u1.username, u2.username;

-- 8. Show the user with the highest number of posts
SELECT u.user_id, u.username, COUNT(p.post_id) AS post_count
FROM users u
JOIN posts p ON u.user_id = p.user_id
GROUP BY u.user_id, u.username
ORDER BY post_count DESC
LIMIT 1;

-- 9. List the top X users with the most followers
SELECT u.user_id, u.username, COUNT(f.follower_id) AS follower_count
FROM users u
JOIN follows f ON u.user_id = f.following_id
GROUP BY u.user_id, u.username
ORDER BY follower_count DESC
LIMIT ?; -- Replace ? with the desired X value

-- 10. Find posts that have been liked by all users
SELECT p.post_id, p.caption, u.username AS creator, p.image, p.likes_count
FROM posts p
JOIN users u ON p.user_id = u.user_id
WHERE p.likes_count = (SELECT COUNT(*) FROM users)
ORDER BY p.create_time DESC;

-- 11. Display the most active user (based on posts, comments, and likes)
SELECT u.user_id, u.username,
       COUNT(DISTINCT p.post_id) AS post_count,
       COUNT(DISTINCT c.comment_id) AS comment_count,
       COUNT(DISTINCT l.post_id) AS like_count,
       (COUNT(DISTINCT p.post_id) + COUNT(DISTINCT c.comment_id) + COUNT(DISTINCT l.post_id)) AS total_activity
FROM users u
LEFT JOIN posts p ON u.user_id = p.user_id
LEFT JOIN comments c ON u.user_id = c.user_id
LEFT JOIN likes l ON u.user_id = l.user_id
GROUP BY u.user_id, u.username
ORDER BY total_activity DESC
LIMIT 1;

-- 12. Find the average number of likes per post for each user
SELECT u.user_id, u.username, 
       COUNT(DISTINCT p.post_id) AS post_count,
       SUM(p.likes_count) AS total_likes,
       ROUND(AVG(p.likes_count), 2) AS avg_likes_per_post
FROM users u
JOIN posts p ON u.user_id = p.user_id
GROUP BY u.user_id, u.username
HAVING post_count > 0
ORDER BY avg_likes_per_post DESC;

-- 13. Show posts that have more comments than likes
SELECT p.post_id, p.caption, u.username AS creator, 
       p.likes_count, p.comments_count
FROM posts p
JOIN users u ON p.user_id = u.user_id
WHERE p.comments_count > p.likes_count
ORDER BY (p.comments_count - p.likes_count) DESC;

-- 14. List the users who have liked every post of a specific user
SELECT l_user.user_id, l_user.username
FROM users l_user
WHERE NOT EXISTS (
    SELECT p.post_id
    FROM posts p
    WHERE p.user_id = ? -- Replace ? with the specific user ID
    AND NOT EXISTS (
        SELECT 1
        FROM likes l
        WHERE l.post_id = p.post_id
        AND l.user_id = l_user.user_id
    )
)
AND l_user.user_id != ?; -- Exclude the user themselves

-- 15. Display the most popular post of each user (based on likes)
SELECT p.user_id, u.username, p.post_id, p.caption, p.likes_count, p.image
FROM posts p
JOIN users u ON p.user_id = u.user_id
WHERE (p.user_id, p.likes_count) IN (
    SELECT p_inner.user_id, MAX(p_inner.likes_count)
    FROM posts p_inner
    GROUP BY p_inner.user_id
)
ORDER BY p.likes_count DESC;

-- 16. Find the user(s) with the highest ratio of followers to following
SELECT u.user_id, u.username, 
       u.followersCount AS followers,
       u.followingCount AS following,
       ROUND(u.followersCount / GREATEST(u.followingCount, 1), 2) AS follower_ratio
FROM users u
WHERE u.followingCount > 0
ORDER BY follower_ratio DESC
LIMIT 10;

-- 17. Show the month with the highest number of posts made
SELECT 
    YEAR(create_time) AS post_year,
    MONTH(create_time) AS post_month,
    MONTHNAME(create_time) AS month_name,
    COUNT(*) AS post_count
FROM posts
GROUP BY post_year, post_month, month_name
ORDER BY post_count DESC
LIMIT 1;

-- 18. Identify users who have not interacted with a specific user's posts
SELECT u.user_id, u.username
FROM users u
WHERE u.user_id NOT IN (
    SELECT DISTINCT c.user_id
    FROM comments c
    JOIN posts p ON c.post_id = p.post_id
    WHERE p.user_id = ? -- Replace ? with the specific user ID
)
AND u.user_id NOT IN (
    SELECT DISTINCT l.user_id
    FROM likes l
    JOIN posts p ON l.post_id = p.post_id
    WHERE p.user_id = ? -- Replace ? with the same specific user ID
)
AND u.user_id != ?; -- Exclude the user themselves

-- 19. Display the user with the greatest increase in followers in the last X days
-- Note: This assumes we have historical data on follower counts
-- For this example, we'll use the follow_date in the follows table
SELECT 
    u.user_id, 
    u.username,
    COUNT(f.follower_id) AS new_followers
FROM users u
JOIN follows f ON u.user_id = f.following_id
WHERE f.follow_date >= DATE_SUB(CURRENT_DATE, INTERVAL ? DAY) -- Replace ? with X days
GROUP BY u.user_id, u.username
ORDER BY new_followers DESC
LIMIT 1;

-- 20. Find users who are followed by more than X% of the platform users
SELECT 
    u.user_id, 
    u.username,
    COUNT(f.follower_id) AS follower_count,
    (SELECT COUNT(*) FROM users) AS total_users,
    ROUND((COUNT(f.follower_id) / (SELECT COUNT(*) FROM users)) * 100, 2) AS percentage
FROM users u
JOIN follows f ON u.user_id = f.following_id
GROUP BY u.user_id, u.username
HAVING percentage > ? -- Replace ? with the desired percentage
ORDER BY percentage DESC;
